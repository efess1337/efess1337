const state = { csrf: "" };

async function api(path, opts = {}) {
  const headers = Object "Content-Type": "application/json", ...(opts.headers || {}) };
  if (state.csrf && opts.method && opts.method !== "GET") headers["X-CSRF"] = state.csrf;
  const res = await fetch(path, {
    credentials: "same-origin",
    ...opts,
    headers,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch {}
  if (!res.ok) throw new Error(data.detail || ("HTTP " + res.status));
  return data;
}

function $(id) { return document.getElementById(id); }
function showGate(msg) {
  $("gate").classList.remove("hidden");
  $("dash").classList.add("hidden");
  if (msg) { $("gateMsg").textContent = msg; $("gateMsg").className = "msg"; }
}
function showDash() {
  $("gate").classList.add("hidden");
  $("dash").classList.remove("hidden");
}
function fmtTs(ts) {
  if (!ts) return "never";
  return new Date(ts * 1000).toLocaleString();
}
function short(s, n = 14) {
  if (!s) return "-";
  return s.length > n ? s.slice(0, n) + "…" : s;
}

async function refresh() {
  const [me, stats, users, audit] = await Promise.all([
    api("/api/admin/me"),
    api("/api/admin/stats"),
    api("/api/admin/users"),
    api("/api/admin/audit"),
  ]);
  state.csrf = me.csrf || state.csrf;
  $("who").textContent = "admin · " + me.username;
  $("sUsers").textContent = stats.users;
  $("sBanned").textContent = stats.banned;
  $("sSessions").textContent = stats.sessions;

  const tb = $("userRows");
  tb.innerHTML = "";
  for (const u of users.users) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${escapeHtml(u.username)}</strong></td>
      <td><code>${escapeHtml(u.license_key)}</code></td>
      <td><code title="${escapeHtml(u.hwid || "")}">${escapeHtml(short(u.hwid, 12))}</code></td>
      <td>${escapeHtml(fmtTs(u.expires_at))}</td>
      <td><span class="badge ${u.banned ? "on" : "off"}">${u.banned ? "BAN" : "OK"}</span></td>
      <td class="row-actions"></td>`;
    const actions = tr.querySelector(".row-actions");
    actions.append(
      btn(u.banned ? "Unban" : "Ban", () => banUser(u.username, !u.banned)),
      btn("HWID", () => resetHwid(u.username)),
      btn("+30g", () => extendUser(u.username, 30)),
      btn("Sil", () => delUser(u.username), true),
    );
    tb.appendChild(tr);
  }

  const ab = $("auditRows");
  ab.innerHTML = "";
  for (const a of audit.items) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${escapeHtml(fmtTs(a.ts))}</td>
      <td><code>${escapeHtml(a.ip || "")}</code></td>
      <td>${escapeHtml(a.username || "")}</td>
      <td>${escapeHtml(a.action || "")}</td>
      <td>${a.ok ? "✓" : "✗"}</td>
      <td>${escapeHtml(a.detail || "")}</td>`;
    ab.appendChild(tr);
  }
}

function btn(label, fn, danger = false) {
  const b = document.createElement("button");
  b.className = "btn tiny" + (danger ? " danger" : "");
  b.textContent = label;
  b.type = "button";
  b.onclick = fn;
  return b;
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

async function banUser(username, banned) {
  await api("/api/admin/users/ban", { method: "POST", body: { username, banned } });
  await refresh();
}
async function resetHwid(username) {
  if (!confirm(username + " HWID sıfırlansın mı?")) return;
  await api("/api/admin/users/reset-hwid", { method: "POST", body: { username } });
  await refresh();
}
async function extendUser(username, days) {
  await api("/api/admin/users/extend", { method: "POST", body: { username, days } });
  await refresh();
}
async function delUser(username) {
  if (!confirm(username + " silinsin mi?")) return;
  await api("/api/admin/users/delete", { method: "POST", body: { username } });
  await refresh();
}

$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("gateMsg").textContent = "";
  try {
    const data = await api("/api/admin/login", {
      method: "POST",
      body: { username: $("user").value.trim(), password: $("pass").value },
    });
    state.csrf = data.csrf;
    showDash();
    await refresh();
  } catch (err) {
    $("gateMsg").textContent = err.message;
  }
});

$("createForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const msg = $("createMsg");
  msg.className = "msg";
  msg.textContent = "";
  try {
    const data = await api("/api/admin/users/create", {
      method: "POST",
      body: {
        username: $("cUser").value.trim(),
        password: $("cPass").value,
        days: Number($("cDays").value || 30),
        note: $("cNote").value,
      },
    });
    msg.className = "msg ok";
    msg.textContent = "OK · key " + data.license_key;
    $("cUser").value = "";
    $("cPass").value = "";
    await refresh();
  } catch (err) {
    msg.textContent = err.message;
  }
});

$("logoutBtn").onclick = async () => {
  try { await api("/api/admin/logout", { method: "POST", body: {} }); } catch {}
  state.csrf = "";
  showGate();
};
$("refreshBtn").onclick = () => refresh().catch((e) => alert(e.message));

(async () => {
  try {
    const me = await api("/api/admin/me");
    state.csrf = me.csrf;
    showDash();
    await refresh();
  } catch {
    showGate();
  }
})();
